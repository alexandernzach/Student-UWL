5Return=int(input("please enter a number"))

sum=5Return
print(sum)
