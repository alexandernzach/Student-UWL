print(2/3)
print(2//3)

