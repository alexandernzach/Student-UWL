print ("Hello world")
print ("I am in my ISD class right now")
