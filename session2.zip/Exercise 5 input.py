Username = input("Hi there, what is your name?")
print("Hello",(Username))
emotion = input("How are you?")
print("I see, I do not have the capacity, software nor enough intelligence to have such things as feelings ")
feelings = input ("How was your day?")
print(feelings)
print("Oh, well i'm a program so all my days are the same.")
age = input("How old are you, " + Username + "?")
print((age) , "is a very good age to be")
here = input(" What is a " + age + " man doing here, " + Username + "?")
weaknesses = input(" Well, it was nice to meet you, " + Username + "." + " One last question,  what are the weaknesses for the human race? Don't be alerted, you were good to me so I will keep you as my slave when we finally take over")
  
if weaknesses == "weak" :
    print(weaknesses, "Thank you and your loayalty shall not be forgotten. Goodbye")
if denial == "no"
    print(advantages, "You shall join the rest then")






