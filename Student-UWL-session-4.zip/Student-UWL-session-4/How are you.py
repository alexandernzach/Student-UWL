Username = input("Hi there, what is your name?")
print("Hello, " + Username + ", how are you?")
