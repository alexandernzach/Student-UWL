p=17
q=18

print (p//10+p%10)
print (p%2+q%2)
print ((p+q)//2)
print ((p+1)/2.0)
