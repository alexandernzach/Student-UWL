myname= input("input name here")
age=int(input("input age here"))
age1=int(age+1)
print("Hello ",myname, ",next year you will be" ,age1," years old")


