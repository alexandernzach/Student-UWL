radius=2
area=12.57

print ("Radius is:","\t",radius)
print ("Area is:","\t",area)
