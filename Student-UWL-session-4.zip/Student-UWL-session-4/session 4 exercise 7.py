from math import sqrt
X = 2
Y = 4
print("The product of ", X, "and", Y, "is", X + Y)
print("The root of their difference is ", sqrt(X-Y))
