a=int((3 + 4 + 5)/ 3)
print (a)
