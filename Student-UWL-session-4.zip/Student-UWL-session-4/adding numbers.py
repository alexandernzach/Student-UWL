print("Add two numbers together")

# The program is asking for 2 numbers.

Number1=int(input("Enter one number"))

Number2=int(input("Enter one number"))

# The numbers will be added together.

sum=Number1+Number2

#The sum of the two added numbers will be displayed here.

print(sum)
            
