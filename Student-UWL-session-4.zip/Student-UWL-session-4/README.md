# Student-UWL
Here go my practical projects for UWL isd.
