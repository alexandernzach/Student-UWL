radius = int(input("Radius:"))
x = 3.14
pi = x
area = pi * radius ** 2
print (area)
